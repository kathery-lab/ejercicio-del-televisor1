package televisor;

public class Main {

	public static void main(String[] args) {
	        Samsung tv1 = new Samsung("Samsung", "Q80C", 55, "4K", "Tizen");
	        LG tv2 = new LG("LG", "OLED Evo", 65, "4K", true);
	        Sony tv3 = new Sony("Sony", "Bravia XR", 75, "4K", "Dolby Atmos");
	        TCL tv4 = new TCL("TCL", "P755", 50, "4K", "Sí");

	        System.out.println("== Televisor Samsung ==");
	        tv1.mostrarSamsung();

	        System.out.println("\n== Televisor LG ==");
	        tv2.mostrarLG();

	        System.out.println("\n== Televisor Sony ==");
	        tv3.mostrarSony();

	        System.out.println("\n== Televisor TCL ==");
	        tv4.mostrarTCL();
	    }
	}

		

	