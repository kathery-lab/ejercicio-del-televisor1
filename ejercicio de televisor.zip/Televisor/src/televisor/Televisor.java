package televisor;

public class Televisor {
	private String marca;
    private String modelo;
    private int pulgadas;
    private String resolucion;

    public Televisor(String marca, String modelo, int pulgadas, String resolucion) {
        this.marca = marca;
        this.modelo = modelo;
        this.pulgadas = pulgadas;
        this.resolucion = resolucion;
    }

     public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getPulgadas() {
        return pulgadas;
    }

    public String getResolucion() {
        return resolucion;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setPulgadas(int pulgadas) {
        this.pulgadas = pulgadas;
    }

    public void setResolucion(String resolucion) {
        this.resolucion = resolucion;
    }

    public void mostrarInformacion() {
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Pulgadas: " + pulgadas);
        System.out.println("Resolución: " + resolucion);
    }
}

class Samsung extends Televisor {
    private String sistemaOperativo;

    public Samsung(String marca, String modelo, int pulgadas, String resolucion, String sistemaOperativo) {
        super(marca, modelo, pulgadas, resolucion);
        this.sistemaOperativo = sistemaOperativo;
    }

    public String getSistemaOperativo() {
        return sistemaOperativo;
    }

    public void setSistemaOperativo(String sistemaOperativo) {
        this.sistemaOperativo = sistemaOperativo;
    }

    public void mostrarSamsung() {
        mostrarInformacion();
        System.out.println("Sistema Operativo: " + sistemaOperativo);
    }
}

class LG extends Televisor {
    private boolean oled;

    public LG(String marca, String modelo, int pulgadas, String resolucion, boolean oled) {
        super(marca, modelo, pulgadas, resolucion);
        this.oled = oled;
    }

    public boolean isOled() {
        return oled;
    }

    public void setOled(boolean oled) {
        this.oled = oled;
    }

    public void mostrarLG() {
        mostrarInformacion();
        System.out.println("Tecnología OLED: " + oled);
    }
}

class Sony extends Televisor {
    private String sonido;

    public Sony(String marca, String modelo, int pulgadas, String resolucion, String sonido) {
        super(marca, modelo, pulgadas, resolucion);
        this.sonido = sonido;
    }

    public String getSonido() {
        return sonido;
    }

    public void setSonido(String sonido) {
        this.sonido = sonido;
    }

    public void mostrarSony() {
        mostrarInformacion();
        System.out.println("Sistema de sonido: " + sonido);
    }
}

class TCL extends Televisor {
    private String controlVoz;

    public TCL(String marca, String modelo, int pulgadas, String resolucion, String controlVoz) {
        super(marca, modelo, pulgadas, resolucion);
        this.controlVoz = controlVoz;
    }

    public String getControlVoz() {
        return controlVoz;
    }

    public void setControlVoz(String controlVoz) {
        this.controlVoz = controlVoz;
    }

    public void mostrarTCL() {
        mostrarInformacion();
        System.out.println("Control por voz: " + controlVoz);
    }
}


